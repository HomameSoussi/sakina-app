// Global Jest teardown
module.exports = async () => {
  // Clean up any global test resources
  // This could include cleaning up test database, stopping test servers, etc.
  
  console.log('🧹 Global test teardown complete');
};
